﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        //Declaring all the needed variables
        public string WEBSITE1 { get; set; }

        public string WEBSITE2 { get; set; }
        public string NAME { get; set; }
        public int ID { get; set; }
        public int PRICES { get; set; }
        public string MOVIE { get; set; }

        private Dictionary<string, string> WEBSITEONE = new Dictionary<string, string>();

        private Dictionary<string, string> WEBSITETWO = new Dictionary<string, string>();

        //Dictionary for all movies
        public Dictionary<string, string> MOVIE1 = new Dictionary<string, string>();
        public Dictionary<string, string> MOVIE2 = new Dictionary<string, string>();
        public Dictionary<string, string> MOVIE3 = new Dictionary<string, string>();
        public Dictionary<string, string> MOVIE4 = new Dictionary<string, string>();
        public Dictionary<string, string> MOVIE5 = new Dictionary<string, string>();
        public Dictionary<string, string> MOVIE6 = new Dictionary<string, string>();
        public Dictionary<string, string> MOVIE7 = new Dictionary<string, string>();
        public Dictionary<string, string> MOVIE8 = new Dictionary<string, string>();

        //Creating a web client
        WebClient webClient;
        String URLFilename = "";
        String directoryName = "";
        String fileName;
        String price1;
        String price2;
        String textBar;
        String cheaperSite;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //Perform this function on Search Button Click
        protected void buttonClick(object sender, EventArgs e)
        {

            SavingFiles();
        }

        //This method downloads the text file from internet, saves it in a local folder and stores all the information on it into the assigned variables
        public void SavingFiles()
        {
            webClient = new WebClient();

            try
            {
                URLFilename = @"http://m.uploadedit.com/bbtc/1523377557810.txt";
                webClient.DownloadFile(URLFilename, @"C:/temp/movies1.txt");
            }
            catch (Exception e)
            {
                fileName = @"C:/temp/movies1.txt";
            }

            fileName = @"C:/temp/movies1.txt";


            directoryName = Path.GetDirectoryName(fileName);

            if (File.Exists(fileName))
            {
                StreamReader fileIn = new StreamReader(fileName);
                String line;

                // read and write line by line
                // Trims all the extra characters from the data line
                while (!fileIn.EndOfStream)
                {
                    line = fileIn.ReadLine();
                    int index = line.IndexOf(@"//");
                    if (index >= 0)
                        line = line.Remove(index);
                    line = line.Trim();
                    if (line.Length == 0)
                        continue;

                    var newKey = line.Trim('"');
                    string[] keyValue = newKey.Split(new Char[] { '=' });

                    //Assigning values to all the data
                    if (keyValue[0] == "WEBSITE1")

                    {
                        WEBSITE1 = keyValue[1];

                    }
                    if (keyValue[0] == "WEBSITE2")

                    {
                        WEBSITE2 = keyValue[1];

                    }
                    //Assigning values to all the data
                    else if (keyValue[0] == "MOVIE1")
                    {
                        if (File.Exists(fileName))
                        {

                            StreamReader fileIn1 = new StreamReader(fileName);
                            String line1;

                            // read and write line by line
                            // Trims all the extra characters from the data line
                            while (!fileIn1.EndOfStream)
                            {

                                line1 = fileIn1.ReadLine();

                                int index1 = line1.IndexOf(@"//");
                                if (index1 == 0)
                                    line1 = line1.Remove(index1);
                                line1 = line1.Trim();
                                if (line1.Length == 0)
                                    continue;

                                //Assigning values to all the data
                                if (line1.Contains("MOVIE1"))
                                {
                                    string newLine = line1.Trim().Replace("MOVIE1=", " ");

                                    string[] keyValue1 = newLine.Split(new Char[] { ',' });
                                    foreach (var item in keyValue1)
                                    {

                                        string[] data = item.Split(new Char[] { '=' });
                                        MOVIE1.Add(data[0], data[1]);

                                  }
                                }
                                
                            }
                        }
                        //Extracting the name and price of the movie and inserting it into the website dictionary
                        string name = MOVIE1["NAME"];
                        string price = MOVIE1["PRICES"];
                        WEBSITEONE.Add(name, price);
                    }
                    else if (keyValue[0] == "MOVIE2")
                    {
                        if (File.Exists(fileName))
                        {

                            StreamReader fileIn1 = new StreamReader(fileName);
                            String line1;

                            // read and write line by line
                            // Trims all the extra characters from the data line
                            while (!fileIn1.EndOfStream)
                            {

                                line1 = fileIn1.ReadLine();

                                int index1 = line1.IndexOf(@"//");
                                if (index1 == 0)
                                    line1 = line1.Remove(index1);
                                line1 = line1.Trim();
                                if (line1.Length == 0)
                                    continue;

                                //Assigning values to all the data
                                if (line1.Contains("MOVIE2"))
                                {
                                    string newLine = line1.Trim().Replace("MOVIE2=", " ");

                                    string[] keyValue1 = newLine.Split(new Char[] { ',' });
                                    foreach (var item in keyValue1)
                                    {

                                        string[] data = item.Split(new Char[] { '=' });
                                        MOVIE2.Add(data[0], data[1]);

                                    }
                                }
                            }
                        }
                        //Extracting the name and price of the movie and inserting it into the website dictionary
                        string name = MOVIE2["NAME"];
                        string price = MOVIE2["PRICES"];
                        WEBSITEONE.Add(name, price);

                    }
                    else if (keyValue[0] == "MOVIE3")
                    {
                        if (File.Exists(fileName))
                        {

                            StreamReader fileIn1 = new StreamReader(fileName);
                            String line1;

                            // read and write line by line
                            // Trims all the extra characters from the data line
                            while (!fileIn1.EndOfStream)
                            {

                                line1 = fileIn1.ReadLine();

                                int index1 = line1.IndexOf(@"//");
                                if (index1 == 0)
                                    line1 = line1.Remove(index1);
                                line1 = line1.Trim();
                                if (line1.Length == 0)
                                    continue;

                                //Assigning values to all the data
                                if (line1.Contains("MOVIE3"))
                                {
                                    string newLine = line1.Trim().Replace("MOVIE3=", " ");

                                    string[] keyValue1 = newLine.Split(new Char[] { ',' });
                                    foreach (var item in keyValue1)
                                    {

                                        string[] data = item.Split(new Char[] { '=' });
                                        MOVIE3.Add(data[0], data[1]);

                                    }
                                }
                            }
                        }
                        //Extracting the name and price of the movie and inserting it into the website dictionary
                        string name = MOVIE3["NAME"];
                        string price = MOVIE3["PRICES"];
                        WEBSITEONE.Add(name, price);
                    }
                    else if (keyValue[0] == "MOVIE4")
                    {
                        if (File.Exists(fileName))
                        {

                            StreamReader fileIn1 = new StreamReader(fileName);
                            String line1;

                            // read and write line by line
                            // Trims all the extra characters from the data line
                            while (!fileIn1.EndOfStream)
                            {

                                line1 = fileIn1.ReadLine();

                                int index1 = line1.IndexOf(@"//");
                                if (index1 == 0)
                                    line1 = line1.Remove(index1);
                                line1 = line1.Trim();
                                if (line1.Length == 0)
                                    continue;

                                //Assigning values to all the data
                                if (line1.Contains("MOVIE4"))
                                {
                                    string newLine = line1.Trim().Replace("MOVIE4=", " ");

                                    string[] keyValue1 = newLine.Split(new Char[] { ',' });
                                    foreach (var item in keyValue1)
                                    {

                                        string[] data = item.Split(new Char[] { '=' });
                                        MOVIE4.Add(data[0], data[1]);

                                    }
                                }
                            }
                        }
                        //Extracting the name and price of the movie and inserting it into the website dictionary
                        string name = MOVIE4["NAME"];
                        string price = MOVIE4["PRICES"];
                        WEBSITEONE.Add(name, price);
                    }

                    else if (keyValue[0] == "MOVIE5")
                    {
                        if (File.Exists(fileName))
                        {

                            StreamReader fileIn1 = new StreamReader(fileName);
                            String line1;

                            // read and write line by line
                            // Trims all the extra characters from the data line
                            while (!fileIn1.EndOfStream)
                            {

                                line1 = fileIn1.ReadLine();

                                int index1 = line1.IndexOf(@"//");
                                if (index1 == 0)
                                    line1 = line1.Remove(index1);
                                line1 = line1.Trim();
                                if (line1.Length == 0)
                                    continue;

                                //Assigning values to all the data
                                if (line1.Contains("MOVIE5"))
                                {
                                    string newLine = line1.Trim().Replace("MOVIE5=", " ");

                                    string[] keyValue1 = newLine.Split(new Char[] { ',' });
                                    foreach (var item in keyValue1)
                                    {

                                        string[] data = item.Split(new Char[] { '=' });
                                        MOVIE5.Add(data[0], data[1]);

                                    }
                                }
                            }
                        }
                        //Extracting the name and price of the movie and inserting it into the website dictionary
                        string name = MOVIE5["NAME"];
                        string price = MOVIE5["PRICES"];
                        WEBSITETWO.Add(name, price);
                    }

                    else if (keyValue[0] == "MOVIE6")
                    {
                        if (File.Exists(fileName))
                        {

                            StreamReader fileIn1 = new StreamReader(fileName);
                            String line1;

                            // read and write line by line
                            // Trims all the extra characters from the data line
                            while (!fileIn1.EndOfStream)
                            {

                                line1 = fileIn1.ReadLine();

                                int index1 = line1.IndexOf(@"//");
                                if (index1 == 0)
                                    line1 = line1.Remove(index1);
                                line1 = line1.Trim();
                                if (line1.Length == 0)
                                    continue;

                                //Assigning values to all the data
                                if (line1.Contains("MOVIE6"))
                                {
                                    string newLine = line1.Trim().Replace("MOVIE6=", " ");

                                    string[] keyValue1 = newLine.Split(new Char[] { ',' });
                                    foreach (var item in keyValue1)
                                    {

                                        string[] data = item.Split(new Char[] { '=' });
                                        MOVIE6.Add(data[0], data[1]);

                                    }
                                }
                            }
                        }
                        //Extracting the name and price of the movie and inserting it into the website dictionary
                        string name = MOVIE6["NAME"];
                        string price = MOVIE6["PRICES"];
                        WEBSITETWO.Add(name, price);
                    }

                    else if (keyValue[0] == "MOVIE7")
                    {
                        if (File.Exists(fileName))
                        {

                            StreamReader fileIn1 = new StreamReader(fileName);
                            String line1;

                            // read and write line by line
                            // Trims all the extra characters from the data line
                            while (!fileIn1.EndOfStream)
                            {

                                line1 = fileIn1.ReadLine();

                                int index1 = line1.IndexOf(@"//");
                                if (index1 == 0)
                                    line1 = line1.Remove(index1);
                                line1 = line1.Trim();
                                if (line1.Length == 0)
                                    continue;

                                //Assigning values to all the data
                                if (line1.Contains("MOVIE7"))
                                {
                                    string newLine = line1.Trim().Replace("MOVIE7=", " ");

                                    string[] keyValue1 = newLine.Split(new Char[] { ',' });
                                    foreach (var item in keyValue1)
                                    {

                                        string[] data = item.Split(new Char[] { '=' });
                                        MOVIE7.Add(data[0], data[1]);

                                    }
                                }
                            }
                        }
                        //Extracting the name and price of the movie and inserting it into the website dictionary
                        string name = MOVIE7["NAME"];
                        string price = MOVIE7["PRICES"];
                        WEBSITETWO.Add(name, price);
                    }

                    else if (keyValue[0] == "MOVIE8")
                    {
                        if (File.Exists(fileName))
                        {

                            StreamReader fileIn1 = new StreamReader(fileName);
                            String line1;

                            // read and write line by line
                            // Trims all the extra characters from the data line
                            while (!fileIn1.EndOfStream)
                            {

                                line1 = fileIn1.ReadLine();

                                int index1 = line1.IndexOf(@"//");
                                if (index1 == 0)
                                    line1 = line1.Remove(index1);
                                line1 = line1.Trim();
                                if (line1.Length == 0)
                                    continue;

                                //Assigning values to all the data
                                if (line1.Contains("MOVIE8"))
                                {
                                    string newLine = line1.Trim().Replace("MOVIE8=", " ");

                                    string[] keyValue1 = newLine.Split(new Char[] { ',' });
                                    foreach (var item in keyValue1)
                                    {

                                        string[] data = item.Split(new Char[] { '=' });
                                        MOVIE8.Add(data[0], data[1]);

                                    }
                                }
                            }
                        }
                        //Extracting the name and price of the movie and inserting it into the website dictionary
                        string name = MOVIE8["NAME"];
                        string price = MOVIE8["PRICES"];
                        WEBSITETWO.Add(name, price);
                    }
                    
                
                }
            }

            //Getting the value entered by the user into the search bar
            textBar = Request["searchMovie"].Trim();

            //If the users enters black panther, this method gets the prices of Black Panther, compares the prices and displays the cheaper website
            if (textBar == "Black Panther" || textBar == "black panther" || textBar == "Black panther")
            {
                NAME = "Black Panther";


                price1 = WEBSITEONE["Black Panther"];
                price2 = WEBSITETWO["Black Panther"];


                if (Convert.ToInt32(price1) < Convert.ToInt32(price2))
                {
                    cheaperSite = WEBSITE1;
                }
                else
                {
                    cheaperSite = WEBSITE2;
                }
            }

            //If the users enters Tomb Raider, this method gets the prices of Tomb Raider, compares the prices and displays the cheaper website
            else if (textBar == "Tomb Raider" || textBar == "tomb raider" || textBar == "Tomb raider")
            {
                
                NAME = "Tomb Raider";


                price1 = WEBSITEONE["Tomb Raider"];
                price2 = WEBSITETWO["Tomb Raider"];


                if (Convert.ToInt32(price1) < Convert.ToInt32(price2))
                {
                    cheaperSite = WEBSITE1;
                }
                else
                {
                    cheaperSite = WEBSITE2;
                }
            }

            //If the users enters Red Sparrow, this method gets the prices of Red Sparrow, compares the prices and displays the cheaper website
            else if (textBar == "Red Sparrow" || textBar == "red sparrow" || textBar == "Red sparrow")
            {
                NAME = "Red Sparrow";


                price1 = WEBSITEONE["Red Sparrow"];
                price2 = WEBSITETWO["Red Sparrow"];


                if (Convert.ToInt32(price1) < Convert.ToInt32(price2))
                {
                    cheaperSite = WEBSITE1;
                }
                else
                {
                    cheaperSite = WEBSITE2;
                }
            }

            //If the users enters Pacific Rim, this method gets the prices of Pacific Rim, compares the prices and displays the cheaper website
            else if (textBar == "Pacific Rim" || textBar == "pacific rim" || textBar == "Pacific rim")
            {
              
                NAME = "Pacific Rim";


                price1 = WEBSITEONE["Pacific Rim"];
                price2 = WEBSITETWO["Pacific Rim"];


                if (Convert.ToInt32(price1) < Convert.ToInt32(price2))
                {
                    cheaperSite = WEBSITE1;
                }
                else
                {
                    cheaperSite = WEBSITE2;
                }
            }

            

        }


        //This method draws the table to display the comparison results
        //It includes the name of the movie, the two comparing websites, the prices and the cheapest website
        public void DrawTable()
        {

            string html = "<table border=1 id=tableResults width=200px height=100px><tr><th>Movie</th><th>Other Sites</th><th>Price</th><th>Cheapest Site</th></tr><tr align=center><td>" + NAME + "</td><td>" + WEBSITE1 + "</br>" + WEBSITE2 + "</td><td>"+ price1 + "</br>" + price2 + "</td><td>" + cheaperSite + "</td></tr></table>";
            Response.Write(html);
        }

     

    }

    }
